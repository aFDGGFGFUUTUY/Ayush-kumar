
from fastapi import FastAPI
from pydantic import BaseModel
from analyzer import analyze_code
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Code(BaseModel):
    code: str

@app.post("/scan")
def scan(data: Code):
    return {"analysis": analyze_code(data.code)}
