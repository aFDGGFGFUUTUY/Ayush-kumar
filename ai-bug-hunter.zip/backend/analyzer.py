
from openai import OpenAI
client = OpenAI()

def analyze_code(code: str):
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert bug finder."},
            {"role": "user", "content": f"Analyze this code and find bugs:\n{code}"}
        ]
    )
    return response.choices[0].message.content
