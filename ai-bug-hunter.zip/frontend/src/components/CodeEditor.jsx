
import { useState } from "react";
import axios from "axios";

export default function CodeEditor(){
  const [code,setCode]=useState("");
  const [res,setRes]=useState("");

  const scan=async()=>{
    const r=await axios.post("http://localhost:8000/scan",{code});
    setRes(r.data.analysis);
  };

  return (
    <div>
      <textarea value={code} onChange={e=>setCode(e.target.value)} />
      <button onClick={scan}>Scan</button>
      <pre>{res}</pre>
    </div>
  )
}
