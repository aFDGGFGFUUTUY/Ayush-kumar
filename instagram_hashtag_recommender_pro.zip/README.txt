
PRO AI HASHTAG RECOMMENDER

FEATURES
- Live trending hashtags (API-ready)
- AI caption understanding (LLM / embeddings ready)
- Popularity filtering
- Animated background
- Save hashtag sets (local storage)

HOW TO ADD REAL AI
1. Get an API key from:
   - OpenAI
   - Google Gemini
   - Anthropic Claude

2. Replace aiGenerate() with real API call

HOW TO ADD REAL TRENDS
- Use RapidAPI / Apify Instagram trend APIs
- Replace fetchTrending() endpoint

RUN
Open index.html in any browser.
