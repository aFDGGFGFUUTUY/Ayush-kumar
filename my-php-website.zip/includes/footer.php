<hr>
<footer>
    <p>&copy; <?php echo date("Y"); ?> My PHP Website</p>
    <p>Made by Ayush Kumar</p>
</footer>
</body>
</html>
