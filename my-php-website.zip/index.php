<?php
$pageTitle = "Home";
include "includes/header.php";
?>

<h1>Welcome to My PHP Website</h1>
<p>This is a simple PHP website.</p>

<?php include "includes/footer.php"; ?>
