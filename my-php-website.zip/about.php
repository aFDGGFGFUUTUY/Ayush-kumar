<?php
$pageTitle = "About";
include "includes/header.php";
?>

<h1>About Us</h1>
<p>This page tells you about the website.</p>

<?php include "includes/footer.php"; ?>
