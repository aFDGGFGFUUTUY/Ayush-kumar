import profile1 from "@/assets/profile-1.jpg";
import profile2 from "@/assets/profile-2.jpg";
import profile3 from "@/assets/profile-3.jpg";
import profile4 from "@/assets/profile-4.jpg";

export interface Profile {
  id: string;
  name: string;
  age: number;
  bio: string;
  location: string;
  distance: string;
  image: string;
  interests: string[];
  personality: string;
  responses: string[];
}

export const profiles: Profile[] = [
  {
    id: "1",
    name: "Sophia",
    age: 24,
    bio: "Art enthusiast & coffee addict ☕ Love exploring hidden gems in the city. Looking for someone who appreciates deep conversations and spontaneous adventures.",
    location: "New York",
    distance: "2 miles away",
    image: profile1,
    interests: ["Art", "Coffee", "Travel", "Music", "Photography"],
    personality: "warm, witty, creative",
    responses: [
      "Hey there! I love your energy 💕 What's the most interesting thing you've done this week?",
      "That's so cool! I actually love trying new things too. Have you been to any good art galleries lately?",
      "Hmm, interesting question! I'd say my favorite place is this tiny coffee shop in Brooklyn. The vibes are immaculate ✨",
      "Haha you're funny! I like that. So what are you looking for on here?",
      "I'm really enjoying talking to you! We should definitely meet up sometime 😊",
    ],
  },
  {
    id: "2",
    name: "Emma",
    age: 26,
    bio: "Yoga instructor by day, foodie by night 🍕 Life's too short for bad vibes. Let's share stories over good wine.",
    location: "Brooklyn",
    distance: "5 miles away",
    image: profile2,
    interests: ["Yoga", "Food", "Wine", "Wellness", "Dancing"],
    personality: "calm, nurturing, passionate",
    responses: [
      "Namaste! 🧘‍♀️ I saw your profile and felt like we might vibe. What brings you here?",
      "I love that perspective! Balance is everything in life, don't you think?",
      "Ooh, have you tried that new Italian place downtown? The pasta is to die for 🍝",
      "You seem really genuine, I appreciate that. It's rare to find these days.",
      "I feel like we have a real connection here. Maybe we could grab coffee soon? ☕",
    ],
  },
  {
    id: "3",
    name: "Isabella",
    age: 23,
    bio: "Software dev who loves hiking 🏔️ Code by day, explore by weekend. Looking for my partner in crime.",
    location: "Manhattan",
    distance: "3 miles away",
    image: profile3,
    interests: ["Hiking", "Tech", "Gaming", "Nature", "Sci-Fi"],
    personality: "curious, adventurous, intellectual",
    responses: [
      "Hey! Your profile caught my eye 👀 Are you into any outdoor activities?",
      "Nice! I just got back from a hike upstate. The views were incredible!",
      "So what do you do? I promise not to talk about code too much 😄",
      "I love how easy you are to talk to. This doesn't happen often!",
      "Okay but seriously, we need to go on an adventure together sometime! 🌲",
    ],
  },
  {
    id: "4",
    name: "Ava",
    age: 25,
    bio: "Music lover & sunset chaser 🌅 Playing guitar, making memories, living life to the fullest. Your adventure buddy awaits!",
    location: "Queens",
    distance: "7 miles away",
    image: profile4,
    interests: ["Music", "Guitar", "Beaches", "Concerts", "Road Trips"],
    personality: "free-spirited, romantic, energetic",
    responses: [
      "Heyyy! 🎸 Your vibe seems super chill. What kind of music are you into?",
      "Oh nice! I'm more into indie and folk but I appreciate all genres. Music brings people together!",
      "Fun fact: I once drove 6 hours just to catch a sunset at the beach. Worth it! 🌅",
      "You're making me smile over here! I can already tell you're special ✨",
      "Okay I'm officially intrigued. Let's make some memories together! 💫",
    ],
  },
];
