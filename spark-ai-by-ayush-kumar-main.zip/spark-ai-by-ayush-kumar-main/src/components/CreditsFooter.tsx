import { motion } from "framer-motion";
import { Heart, Mail, Code } from "lucide-react";

const CreditsFooter = () => {
  return (
    <motion.footer
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="w-full py-6 px-4 mt-4"
    >
      <div className="max-w-md mx-auto glass rounded-2xl p-6 text-center space-y-4">
        <h3 className="font-display text-xl font-bold gradient-text">AK Flare 2004</h3>
        
        <div className="flex items-center justify-center gap-2 text-primary">
          <Heart className="w-5 h-5 fill-primary animate-heart" />
          <span className="font-display text-lg font-semibold">Special Thanks</span>
          <Heart className="w-5 h-5 fill-primary animate-heart" />
        </div>
        
        <div className="space-y-2">
          <p className="text-foreground font-medium flex items-center justify-center gap-2">
            <Code className="w-4 h-4 text-primary" />
            Made by <span className="gradient-text font-bold">Ayush Kumar</span>
          </p>
          <p className="text-sm text-muted-foreground">Professional Developer</p>
        </div>

        <div className="pt-2 border-t border-border">
          <a
            href="mailto:ayush2004@gmail.com"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            <Mail className="w-4 h-4" />
            <span>ayush2004@gmail.com</span>
          </a>
        </div>

        <p className="text-xs text-muted-foreground/60 pt-2">
          Built with ❤️ using React & Framer Motion
        </p>
      </div>
    </motion.footer>
  );
};

export default CreditsFooter;
