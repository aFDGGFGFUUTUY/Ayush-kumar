import { motion, useMotionValue, useTransform, PanInfo } from "framer-motion";
import { Heart, X, MapPin, Sparkles } from "lucide-react";
import { Profile } from "@/data/profiles";

interface SwipeCardProps {
  profile: Profile;
  onSwipe: (direction: "left" | "right") => void;
  isTop: boolean;
}

const SwipeCard = ({ profile, onSwipe, isTop }: SwipeCardProps) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0.5, 1, 1, 1, 0.5]);
  
  const likeOpacity = useTransform(x, [0, 100], [0, 1]);
  const nopeOpacity = useTransform(x, [-100, 0], [1, 0]);

  const handleDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.x > 100) {
      onSwipe("right");
    } else if (info.offset.x < -100) {
      onSwipe("left");
    }
  };

  return (
    <motion.div
      className="absolute w-full h-full cursor-grab active:cursor-grabbing"
      style={{ x, rotate, opacity }}
      drag={isTop ? "x" : false}
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.9}
      onDragEnd={handleDragEnd}
      initial={{ scale: isTop ? 1 : 0.95, y: isTop ? 0 : 20 }}
      animate={{ scale: isTop ? 1 : 0.95, y: isTop ? 0 : 20 }}
      exit={{ 
        x: x.get() > 0 ? 300 : -300, 
        opacity: 0,
        transition: { duration: 0.3 }
      }}
      whileTap={{ scale: isTop ? 1.02 : 0.95 }}
    >
      <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-card">
        {/* Profile Image */}
        <img
          src={profile.image}
          alt={profile.name}
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
        
        {/* Like/Nope Indicators */}
        <motion.div
          className="absolute top-8 right-8 px-6 py-3 rounded-xl border-4 border-green-400 bg-green-400/20 backdrop-blur-sm"
          style={{ opacity: likeOpacity, rotate: 12 }}
        >
          <span className="text-green-400 font-bold text-2xl tracking-wider">LIKE</span>
        </motion.div>
        
        <motion.div
          className="absolute top-8 left-8 px-6 py-3 rounded-xl border-4 border-red-400 bg-red-400/20 backdrop-blur-sm"
          style={{ opacity: nopeOpacity, rotate: -12 }}
        >
          <span className="text-red-400 font-bold text-2xl tracking-wider">NOPE</span>
        </motion.div>
        
        {/* Profile Info */}
        <div className="absolute bottom-0 left-0 right-0 p-6 pb-8">
          <div className="flex items-end justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="font-display text-4xl font-bold text-foreground">
                  {profile.name}
                </h2>
                <span className="text-2xl text-foreground/80">{profile.age}</span>
                <Sparkles className="w-5 h-5 text-primary animate-pulse" />
              </div>
              
              <div className="flex items-center gap-2 text-muted-foreground mb-4">
                <MapPin className="w-4 h-4" />
                <span>{profile.distance}</span>
              </div>
              
              <p className="text-foreground/90 text-sm leading-relaxed line-clamp-2 mb-4">
                {profile.bio}
              </p>
              
              <div className="flex flex-wrap gap-2">
                {profile.interests.slice(0, 4).map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1 rounded-full text-xs font-medium glass"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default SwipeCard;
