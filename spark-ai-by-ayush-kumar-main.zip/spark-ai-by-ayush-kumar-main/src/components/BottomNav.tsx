import { motion } from "framer-motion";
import { Flame, MessageCircle, User, Heart } from "lucide-react";

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  matchCount: number;
}

const BottomNav = ({ activeTab, onTabChange, matchCount }: BottomNavProps) => {
  const tabs = [
    { id: "discover", icon: Flame, label: "Discover" },
    { id: "matches", icon: Heart, label: "Matches" },
    { id: "messages", icon: MessageCircle, label: "Messages" },
    { id: "profile", icon: User, label: "Profile" },
  ];

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 glass border-t border-border px-4 py-2 z-40"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {tabs.map((tab) => (
          <motion.button
            key={tab.id}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
              activeTab === tab.id
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <div className="relative">
              <tab.icon className="w-6 h-6" />
              {tab.id === "matches" && matchCount > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-2 -right-2 w-5 h-5 rounded-full gradient-romantic text-[10px] font-bold flex items-center justify-center text-primary-foreground"
                >
                  {matchCount}
                </motion.span>
              )}
            </div>
            <span className="text-xs font-medium">{tab.label}</span>
            
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary"
              />
            )}
          </motion.button>
        ))}
      </div>
    </motion.nav>
  );
};

export default BottomNav;
