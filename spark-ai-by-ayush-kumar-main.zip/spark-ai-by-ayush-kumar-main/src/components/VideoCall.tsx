import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Phone, 
  Sparkles,
  Heart,
  Volume2,
  VolumeX
} from "lucide-react";
import { Profile } from "@/data/profiles";

interface VideoCallProps {
  profile: Profile;
  onEnd: () => void;
}

const VideoCall = ({ profile, onEnd }: VideoCallProps) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [callDuration, setCallDuration] = useState(0);
  const [isConnecting, setIsConnecting] = useState(true);
  const [aiMessage, setAiMessage] = useState("");
  const [showHeart, setShowHeart] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const speechSynthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const voicesLoadedRef = useRef(false);

  const aiMessages = [
    `Hey! So happy to see you!`,
    `You look amazing today!`,
    `I've been thinking about you...`,
    `Tell me about your day!`,
    `I really enjoy our time together`,
    `You make me smile so much!`,
    `Can we do this more often?`,
    `I love talking with you`,
    `You're so sweet!`,
    `I can't stop smiling when I'm with you`,
  ];

  // Get a female voice for realistic effect
  const getVoice = useCallback(() => {
    const voices = window.speechSynthesis.getVoices();
    // Prefer female voices
    const femaleVoice = voices.find(
      (voice) =>
        voice.name.toLowerCase().includes("female") ||
        voice.name.toLowerCase().includes("samantha") ||
        voice.name.toLowerCase().includes("victoria") ||
        voice.name.toLowerCase().includes("karen") ||
        voice.name.toLowerCase().includes("moira") ||
        voice.name.toLowerCase().includes("tessa") ||
        voice.name.includes("Google UK English Female") ||
        voice.name.includes("Microsoft Zira")
    );
    return femaleVoice || voices.find((v) => v.lang.startsWith("en")) || voices[0];
  }, []);

  // Speak message with voice
  const speakMessage = useCallback((message: string) => {
    if (!voiceEnabled || typeof window === "undefined" || !window.speechSynthesis) return;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.voice = getVoice();
    utterance.pitch = 1.2; // Slightly higher pitch for feminine voice
    utterance.rate = 0.95; // Slightly slower for natural feel
    utterance.volume = 1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    speechSynthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [voiceEnabled, getVoice]);

  // Load voices
  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        voicesLoadedRef.current = true;
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  // Simulate connection
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsConnecting(false);
      const firstMessage = aiMessages[0];
      setAiMessage(firstMessage);
      setTimeout(() => speakMessage(firstMessage), 500);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Call duration timer
  useEffect(() => {
    if (!isConnecting) {
      const interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isConnecting]);

  // Rotate AI messages with voice
  useEffect(() => {
    if (!isConnecting) {
      const interval = setInterval(() => {
        const randomIndex = Math.floor(Math.random() * aiMessages.length);
        const newMessage = aiMessages[randomIndex];
        setAiMessage(newMessage);
        speakMessage(newMessage);
        
        // Occasionally show heart animation
        if (Math.random() > 0.6) {
          setShowHeart(true);
          setTimeout(() => setShowHeart(false), 2000);
        }
      }, 6000);
      return () => clearInterval(interval);
    }
  }, [isConnecting, speakMessage]);

  // Cleanup speech on unmount
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-background z-50 flex flex-col"
    >
      {/* Main Video Area (AI) */}
      <div className="relative flex-1 overflow-hidden">
        {/* AI Video Background */}
        <div className="absolute inset-0">
          <img
            src={profile.image}
            alt={profile.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
          
          {/* Animated overlay for "video" effect */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10"
            animate={{
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </div>

        {/* Connection Overlay */}
        <AnimatePresence>
          {isConnecting && (
            <motion.div
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-background/90 flex flex-col items-center justify-center z-10"
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-32 h-32 rounded-full overflow-hidden border-4 border-primary shadow-glow mb-6"
              >
                <img
                  src={profile.image}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <h2 className="font-display text-2xl font-bold mb-2">Connecting...</h2>
              <p className="text-muted-foreground flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary animate-pulse" />
                Video call with {profile.name}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Hearts Animation */}
        <AnimatePresence>
          {showHeart && (
            <>
              {[...Array(5)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ 
                    opacity: 0, 
                    y: 100, 
                    x: Math.random() * 200 - 100 + window.innerWidth / 2 
                  }}
                  animate={{ 
                    opacity: [0, 1, 0], 
                    y: -200,
                    scale: [0.5, 1.2, 0.8],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ 
                    duration: 2, 
                    delay: i * 0.2,
                    ease: "easeOut" 
                  }}
                  className="absolute bottom-40 text-primary"
                  style={{ left: `${20 + i * 15}%` }}
                >
                  <Heart className="w-8 h-8 fill-primary" />
                </motion.div>
              ))}
            </>
          )}
        </AnimatePresence>

        {/* AI Speaking Bubble */}
        {!isConnecting && aiMessage && (
          <motion.div
            key={aiMessage}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="absolute bottom-32 left-4 right-4"
          >
            <div className="glass rounded-2xl p-4 max-w-sm mx-auto">
              <div className="flex items-start gap-3">
                <motion.div
                  animate={isSpeaking ? { scale: [1, 1.2, 1] } : {}}
                  transition={{ repeat: Infinity, duration: 0.5 }}
                >
                  <Volume2 className={`w-5 h-5 flex-shrink-0 ${isSpeaking ? 'text-primary' : 'text-muted-foreground'}`} />
                </motion.div>
                <p className="text-sm">{aiMessage}</p>
              </div>
              {isSpeaking && (
                <motion.div 
                  className="mt-2 flex justify-center gap-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-1 bg-primary rounded-full"
                      animate={{ height: [8, 20, 8] }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 0.5, 
                        delay: i * 0.1,
                        ease: "easeInOut"
                      }}
                    />
                  ))}
                </motion.div>
              )}
            </div>
          </motion.div>
        )}

        {/* Top Info Bar */}
        <div className="absolute top-0 left-0 right-0 p-6 flex items-center justify-between">
          <div className="glass rounded-full px-4 py-2 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-medium">{profile.name}</span>
          </div>
          
          {!isConnecting && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass rounded-full px-4 py-2"
            >
              <span className="text-sm font-mono">{formatDuration(callDuration)}</span>
            </motion.div>
          )}
        </div>

        {/* Self Video (Picture-in-Picture) */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="absolute top-20 right-4 w-28 h-40 rounded-2xl overflow-hidden border-2 border-border shadow-lg"
        >
          {isVideoOn ? (
            <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
              <span className="text-4xl">👤</span>
            </div>
          ) : (
            <div className="w-full h-full bg-muted flex items-center justify-center">
              <VideoOff className="w-8 h-8 text-muted-foreground" />
            </div>
          )}
        </motion.div>
      </div>

      {/* Controls */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="p-6 pb-10 glass border-t border-border"
      >
        <div className="flex items-center justify-center gap-6">
          {/* Mute Button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMuted(!isMuted)}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
              isMuted ? "bg-destructive" : "glass"
            }`}
          >
            {isMuted ? (
              <MicOff className="w-6 h-6" />
            ) : (
              <Mic className="w-6 h-6" />
            )}
          </motion.button>

          {/* End Call Button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onEnd}
            className="w-20 h-20 rounded-full bg-destructive flex items-center justify-center shadow-lg"
          >
            <Phone className="w-8 h-8 rotate-[135deg]" />
          </motion.button>

          {/* Video Toggle Button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsVideoOn(!isVideoOn)}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
              !isVideoOn ? "bg-destructive" : "glass"
            }`}
          >
            {isVideoOn ? (
              <Video className="w-6 h-6" />
            ) : (
              <VideoOff className="w-6 h-6" />
            )}
          </motion.button>

          {/* Voice Toggle Button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              setVoiceEnabled(!voiceEnabled);
              if (voiceEnabled) {
                window.speechSynthesis.cancel();
                setIsSpeaking(false);
              }
            }}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
              !voiceEnabled ? "bg-destructive" : "glass"
            }`}
          >
            {voiceEnabled ? (
              <Volume2 className="w-6 h-6" />
            ) : (
              <VolumeX className="w-6 h-6" />
            )}
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default VideoCall;
