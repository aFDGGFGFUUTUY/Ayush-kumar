import { motion } from "framer-motion";
import { X, Heart, Star, RotateCcw } from "lucide-react";

interface ActionButtonsProps {
  onSwipe: (direction: "left" | "right") => void;
  onSuperLike: () => void;
  onUndo: () => void;
  canUndo: boolean;
}

const ActionButtons = ({ onSwipe, onSuperLike, onUndo, canUndo }: ActionButtonsProps) => {
  return (
    <div className="flex items-center justify-center gap-4">
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={onUndo}
        disabled={!canUndo}
        className="w-12 h-12 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-secondary transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
      >
        <RotateCcw className="w-5 h-5" />
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => onSwipe("left")}
        className="w-16 h-16 rounded-full glass flex items-center justify-center group hover:border-destructive/50 transition-all duration-300"
      >
        <X className="w-8 h-8 text-destructive group-hover:scale-110 transition-transform" />
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={onSuperLike}
        className="w-14 h-14 rounded-full glass flex items-center justify-center group hover:border-blue-400/50 transition-all duration-300"
      >
        <Star className="w-6 h-6 text-blue-400 group-hover:scale-110 transition-transform" />
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => onSwipe("right")}
        className="w-16 h-16 rounded-full gradient-romantic flex items-center justify-center shadow-romantic group animate-pulse-glow"
      >
        <Heart className="w-8 h-8 text-primary-foreground group-hover:scale-110 transition-transform" />
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="w-12 h-12 rounded-full glass flex items-center justify-center text-muted-foreground"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
        </svg>
      </motion.button>
    </div>
  );
};

export default ActionButtons;
