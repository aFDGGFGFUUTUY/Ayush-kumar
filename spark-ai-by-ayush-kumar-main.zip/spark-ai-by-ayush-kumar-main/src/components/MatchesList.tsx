import { motion } from "framer-motion";
import { MessageCircle, Heart, Sparkles } from "lucide-react";
import { Profile } from "@/data/profiles";

interface MatchesListProps {
  matches: Profile[];
  onSelectMatch: (profile: Profile) => void;
}

const MatchesList = ({ matches, onSelectMatch }: MatchesListProps) => {
  if (matches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full px-8 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", damping: 10 }}
          className="w-24 h-24 rounded-full glass flex items-center justify-center mb-6"
        >
          <Heart className="w-12 h-12 text-primary" />
        </motion.div>
        <h2 className="font-display text-2xl font-bold mb-2">No Matches Yet</h2>
        <p className="text-muted-foreground">
          Keep swiping to find your perfect match!
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Heart className="w-5 h-5 text-primary" />
        <h2 className="font-display text-2xl font-bold">Your Matches</h2>
        <span className="ml-auto text-sm text-muted-foreground">
          {matches.length} {matches.length === 1 ? "match" : "matches"}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {matches.map((profile, index) => (
          <motion.button
            key={profile.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelectMatch(profile)}
            className="relative aspect-[3/4] rounded-2xl overflow-hidden group"
          >
            <img
              src={profile.image}
              alt={profile.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            
            <div className="absolute bottom-0 left-0 right-0 p-3">
              <div className="flex items-center gap-1 mb-1">
                <h3 className="font-display font-semibold text-foreground">
                  {profile.name}
                </h3>
                <span className="text-sm text-foreground/80">{profile.age}</span>
              </div>
              
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Sparkles className="w-3 h-3 text-primary" />
                <span>AI Companion</span>
              </div>
            </div>
            
            <motion.div
              initial={{ opacity: 0 }}
              whileHover={{ opacity: 1 }}
              className="absolute inset-0 flex items-center justify-center bg-primary/20 backdrop-blur-sm"
            >
              <div className="flex items-center gap-2 text-primary-foreground font-medium">
                <MessageCircle className="w-5 h-5" />
                <span>Start Chat</span>
              </div>
            </motion.div>
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default MatchesList;
