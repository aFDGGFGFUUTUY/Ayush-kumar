import { motion, AnimatePresence } from "framer-motion";
import { Heart, MessageCircle, X } from "lucide-react";
import { Profile } from "@/data/profiles";

interface MatchModalProps {
  isOpen: boolean;
  profile: Profile | null;
  onClose: () => void;
  onChat: () => void;
}

const MatchModal = ({ isOpen, profile, onClose, onChat }: MatchModalProps) => {
  if (!profile) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-background/90 backdrop-blur-xl"
            onClick={onClose}
          />
          
          {/* Glow Effects */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full"
              style={{ background: "var(--gradient-glow)" }}
            />
          </div>
          
          {/* Content */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 50 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative z-10 flex flex-col items-center text-center max-w-sm"
          >
            {/* Close Button */}
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="absolute -top-12 right-0 w-10 h-10 rounded-full glass flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </motion.button>
            
            {/* Hearts Animation */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3, type: "spring", damping: 10 }}
              className="mb-6"
            >
              <div className="relative">
                <Heart className="w-20 h-20 text-primary fill-primary animate-heart" />
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.2, 1] }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="absolute -top-2 -right-2"
                >
                  <Heart className="w-8 h-8 text-secondary fill-secondary" />
                </motion.div>
              </div>
            </motion.div>
            
            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="font-display text-5xl font-bold gradient-text mb-4"
            >
              It's a Match!
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-muted-foreground mb-8"
            >
              You and {profile.name} liked each other
            </motion.p>
            
            {/* Profile Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="relative mb-8"
            >
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-primary shadow-glow">
                <img
                  src={profile.image}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.8, type: "spring" }}
                className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full gradient-romantic flex items-center justify-center"
              >
                <Heart className="w-5 h-5 text-primary-foreground fill-primary-foreground" />
              </motion.div>
            </motion.div>
            
            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="flex gap-4 w-full"
            >
              <button
                onClick={onClose}
                className="flex-1 py-4 rounded-2xl glass font-medium hover:bg-muted/50 transition-colors"
              >
                Keep Swiping
              </button>
              <button
                onClick={onChat}
                className="flex-1 py-4 rounded-2xl gradient-romantic font-medium shadow-romantic flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
              >
                <MessageCircle className="w-5 h-5" />
                Say Hello
              </button>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MatchModal;
