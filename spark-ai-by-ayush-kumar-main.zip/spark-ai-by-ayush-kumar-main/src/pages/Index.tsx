import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, Sparkles } from "lucide-react";
import SwipeCard from "@/components/SwipeCard";
import ActionButtons from "@/components/ActionButtons";
import MatchModal from "@/components/MatchModal";
import ChatInterface from "@/components/ChatInterface";
import BottomNav from "@/components/BottomNav";
import MatchesList from "@/components/MatchesList";
import CreditsFooter from "@/components/CreditsFooter";
import { profiles, Profile } from "@/data/profiles";
import { useToast } from "@/components/ui/use-toast";

const Index = () => {
  const { toast } = useToast();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [swipedProfiles, setSwipedProfiles] = useState<string[]>([]);
  const [matches, setMatches] = useState<Profile[]>([]);
  const [showMatch, setShowMatch] = useState(false);
  const [matchedProfile, setMatchedProfile] = useState<Profile | null>(null);
  const [chatProfile, setChatProfile] = useState<Profile | null>(null);
  const [activeTab, setActiveTab] = useState("discover");

  const availableProfiles = profiles.filter(
    (p) => !swipedProfiles.includes(p.id)
  );

  const handleSwipe = useCallback(
    (direction: "left" | "right") => {
      if (availableProfiles.length === 0) return;

      const currentProfile = availableProfiles[0];
      setSwipedProfiles((prev) => [...prev, currentProfile.id]);

      if (direction === "right") {
        // Simulate match (70% chance)
        if (Math.random() > 0.3) {
          setMatchedProfile(currentProfile);
          setMatches((prev) => [...prev, currentProfile]);
          setTimeout(() => setShowMatch(true), 300);
        } else {
          toast({
            title: "Liked! 💕",
            description: `You liked ${currentProfile.name}`,
          });
        }
      } else {
        toast({
          title: "Passed",
          description: `Maybe next time!`,
        });
      }
    },
    [availableProfiles, toast]
  );

  const handleSuperLike = () => {
    if (availableProfiles.length === 0) return;
    
    const currentProfile = availableProfiles[0];
    setSwipedProfiles((prev) => [...prev, currentProfile.id]);
    setMatchedProfile(currentProfile);
    setMatches((prev) => [...prev, currentProfile]);
    
    toast({
      title: "Super Like! ⭐",
      description: `${currentProfile.name} will definitely see this!`,
    });
    
    setTimeout(() => setShowMatch(true), 300);
  };

  const handleUndo = () => {
    if (swipedProfiles.length === 0) return;
    
    const lastSwiped = swipedProfiles[swipedProfiles.length - 1];
    setSwipedProfiles((prev) => prev.slice(0, -1));
    setMatches((prev) => prev.filter((m) => m.id !== lastSwiped));
    
    toast({
      title: "Undo! ↩️",
      description: "Brought back the last profile",
    });
  };

  const handleMatchChat = () => {
    setShowMatch(false);
    if (matchedProfile) {
      setChatProfile(matchedProfile);
    }
  };

  const handleSelectMatch = (profile: Profile) => {
    setChatProfile(profile);
  };

  if (chatProfile) {
    return (
      <ChatInterface
        profile={chatProfile}
        onBack={() => setChatProfile(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Background Glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] opacity-30"
          style={{ background: "var(--gradient-glow)" }}
        />
      </div>

      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 flex items-center justify-between p-4 pt-6"
      >
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl gradient-romantic flex items-center justify-center shadow-romantic">
            <Flame className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold gradient-text">
              AK Flare 2004
            </h1>
            <p className="text-[10px] text-muted-foreground -mt-1">by Ayush Kumar</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="w-4 h-4 text-primary" />
          <span>AI Companions</span>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 pb-24">
        {activeTab === "discover" && (
          <>
            {/* Card Stack */}
            <div className="relative h-[65vh] mx-4 mt-2">
              <AnimatePresence>
                {availableProfiles.length > 0 ? (
                  availableProfiles
                    .slice(0, 3)
                    .reverse()
                    .map((profile, index) => (
                      <SwipeCard
                        key={profile.id}
                        profile={profile}
                        onSwipe={handleSwipe}
                        isTop={index === availableProfiles.slice(0, 3).length - 1}
                      />
                    ))
                ) : (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute inset-0 flex flex-col items-center justify-center text-center p-8"
                  >
                    <div className="w-24 h-24 rounded-full glass flex items-center justify-center mb-6 animate-float">
                      <Sparkles className="w-12 h-12 text-primary" />
                    </div>
                    <h2 className="font-display text-3xl font-bold mb-2">
                      That's Everyone!
                    </h2>
                    <p className="text-muted-foreground mb-6">
                      You've seen all available profiles. Check back later for more!
                    </p>
                    <button
                      onClick={() => {
                        setSwipedProfiles([]);
                        setMatches([]);
                      }}
                      className="px-6 py-3 rounded-xl gradient-romantic font-medium shadow-romantic"
                    >
                      Start Over
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Action Buttons */}
            {availableProfiles.length > 0 && (
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="mt-6"
              >
                <ActionButtons
                  onSwipe={handleSwipe}
                  onSuperLike={handleSuperLike}
                  onUndo={handleUndo}
                  canUndo={swipedProfiles.length > 0}
                />
              </motion.div>
            )}
          </>
        )}

        {activeTab === "matches" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="h-[calc(100vh-180px)] overflow-y-auto"
          >
            <MatchesList matches={matches} onSelectMatch={handleSelectMatch} />
          </motion.div>
        )}

        {activeTab === "messages" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-4"
          >
            {matches.length > 0 ? (
              <div className="space-y-3">
                <h2 className="font-display text-2xl font-bold mb-6">Messages</h2>
                {matches.map((profile) => (
                  <motion.button
                    key={profile.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setChatProfile(profile)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl glass hover:bg-muted/30 transition-colors"
                  >
                    <div className="relative">
                      <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-primary">
                        <img
                          src={profile.image}
                          alt={profile.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-green-500 border-2 border-background" />
                    </div>
                    <div className="flex-1 text-left">
                      <h3 className="font-display font-semibold">{profile.name}</h3>
                      <p className="text-sm text-muted-foreground truncate">
                        Tap to start chatting...
                      </p>
                    </div>
                    <Sparkles className="w-4 h-4 text-primary" />
                  </motion.button>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[60vh] text-center">
                <div className="w-20 h-20 rounded-full glass flex items-center justify-center mb-4">
                  <Sparkles className="w-10 h-10 text-primary" />
                </div>
                <h2 className="font-display text-xl font-bold mb-2">No Messages Yet</h2>
                <p className="text-muted-foreground">Match with someone to start chatting!</p>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "profile" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-4 flex flex-col items-center pt-8 pb-24 overflow-y-auto h-[calc(100vh-180px)]"
          >
            <div className="w-32 h-32 rounded-full gradient-romantic flex items-center justify-center mb-4 shadow-glow">
              <span className="text-4xl font-display font-bold text-primary-foreground">AK</span>
            </div>
            <h2 className="font-display text-2xl font-bold mb-1">AK Flare 2004</h2>
            <p className="text-primary font-medium mb-1">by Ayush Kumar</p>
            <p className="text-muted-foreground text-sm mb-8">Professional Developer</p>
            
            <div className="w-full max-w-sm space-y-4">
              <div className="p-4 rounded-2xl glass">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Matches</span>
                  <span className="text-primary font-bold">{matches.length}</span>
                </div>
              </div>
              <div className="p-4 rounded-2xl glass">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Profiles Viewed</span>
                  <span className="text-primary font-bold">{swipedProfiles.length}</span>
                </div>
              </div>
              <div className="p-4 rounded-2xl glass">
                <div className="flex items-center justify-between">
                  <span className="font-medium">AI Companions</span>
                  <span className="text-primary font-bold">{profiles.length}</span>
                </div>
              </div>
            </div>

            <CreditsFooter />
          </motion.div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        matchCount={matches.length}
      />

      {/* Match Modal */}
      <MatchModal
        isOpen={showMatch}
        profile={matchedProfile}
        onClose={() => setShowMatch(false)}
        onChat={handleMatchChat}
      />
    </div>
  );
};

export default Index;
