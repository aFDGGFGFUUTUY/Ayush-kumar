import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import CategoryFilter from '@/components/CategoryFilter';
import FoodGrid from '@/components/FoodGrid';
import CustomerReviews from '@/components/CustomerReviews';
import AboutUs from '@/components/AboutUs';
import ContactSection from '@/components/ContactSection';
import CartDrawer from '@/components/CartDrawer';
import ChatBot from '@/components/ChatBot';
import FloatingChatButton from '@/components/FloatingChatButton';
import Footer from '@/components/Footer';
import { CartProvider } from '@/context/CartContext';
import { categories, foodItems } from '@/data/foodData';

const Index: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const filteredItems = useMemo(() => {
    return foodItems.filter((item) => {
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  const popularItems = useMemo(() => {
    return foodItems.filter((item) => item.isPopular);
  }, []);

  return (
    <CartProvider>
      <Helmet>
        <title>Food Stall by Ayush - Delicious Food Delivered Fast</title>
        <meta name="description" content="Order delicious food from Food Stall by Ayush. Fresh pizza, burgers, biryani, and more delivered to your doorstep in 30 minutes." />
        <meta name="keywords" content="food delivery, pizza, burger, biryani, online food order, Ayush Kumar" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onCartClick={() => setIsCartOpen(true)}
          onChatClick={() => setIsChatOpen(true)}
        />

        <main>
          <HeroSection />
          
          <CategoryFilter
            categories={categories}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />

          {/* Show popular items when no filters */}
          {!searchQuery && activeCategory === 'all' && (
            <FoodGrid items={popularItems} title="🔥 Popular Right Now" />
          )}

          <FoodGrid 
            items={filteredItems} 
            title={searchQuery ? `Search results for "${searchQuery}"` : activeCategory !== 'all' ? categories.find(c => c.id === activeCategory)?.name : "Our Menu"} 
          />

          <CustomerReviews />
          <AboutUs />
          <ContactSection />
        </main>

        <Footer />

        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
        <ChatBot isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
        <FloatingChatButton isOpen={isChatOpen} onClick={() => setIsChatOpen(true)} />
      </div>
    </CartProvider>
  );
};

export default Index;
