import React from 'react';
import FoodCard from './FoodCard';
import { FoodItem } from '@/types/food';

interface FoodGridProps {
  items: FoodItem[];
  title?: string;
}

const FoodGrid: React.FC<FoodGridProps> = ({ items, title }) => {
  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <p className="text-6xl mb-4">🍽️</p>
          <h3 className="font-display text-2xl font-bold text-foreground mb-2">
            No items found
          </h3>
          <p className="text-muted-foreground">
            Try adjusting your search or category filter
          </p>
        </div>
      </div>
    );
  }

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        {title && (
          <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-6">
            {title}
          </h2>
        )}
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {items.map((item, index) => (
            <FoodCard key={item.id} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FoodGrid;
