import React from 'react';
import { ArrowRight, Star, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-hero py-12 md:py-20">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-20 h-20 bg-food-orange/10 rounded-full blur-2xl animate-float" />
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-food-coral/10 rounded-full blur-3xl animate-float-slow" />
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-food-gold/20 rounded-full blur-xl animate-float animation-delay-200" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Content */}
          <div className="space-y-6 text-center md:text-left">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium animate-slide-up">
              <Star className="w-4 h-4 fill-current" />
              #1 Food Delivery in Town
            </div>

            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight animate-slide-up animation-delay-100">
              Delicious Food
              <span className="block text-gradient">Delivered Fast</span>
            </h1>

            <p className="text-lg text-muted-foreground max-w-md mx-auto md:mx-0 animate-slide-up animation-delay-200">
              Experience the best flavors from top restaurants. Fresh, hot, and delivered right to your doorstep.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start animate-slide-up animation-delay-300">
              <Button variant="hero" size="xl">
                Order Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button variant="outline" size="xl" className="rounded-full">
                View Menu
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap justify-center md:justify-start gap-6 pt-4 animate-slide-up animation-delay-400">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">30 min</p>
                  <p className="text-xs text-muted-foreground">Delivery</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Star className="w-5 h-5 text-primary fill-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">4.9</p>
                  <p className="text-xs text-muted-foreground">Rating</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">100+</p>
                  <p className="text-xs text-muted-foreground">Locations</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Content - Food Images */}
          <div className="relative h-[300px] md:h-[400px] flex items-center justify-center">
            {/* Main food image */}
            <div className="absolute w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden shadow-card animate-float z-20">
              <img
                src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400"
                alt="Delicious Pizza"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Floating food items */}
            <div className="absolute top-0 right-0 md:right-10 w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden shadow-soft animate-float-slow animation-delay-200 z-10">
              <img
                src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300"
                alt="Burger"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="absolute bottom-0 left-0 md:left-10 w-20 h-20 md:w-28 md:h-28 rounded-full overflow-hidden shadow-soft animate-float animation-delay-300 z-10">
              <img
                src="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300"
                alt="Biryani"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="absolute bottom-10 right-0 w-16 h-16 md:w-24 md:h-24 rounded-full overflow-hidden shadow-soft animate-float-slow animation-delay-400">
              <img
                src="https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=300"
                alt="Dessert"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Decorative circle */}
            <div className="absolute w-72 h-72 md:w-96 md:h-96 border-4 border-dashed border-primary/20 rounded-full animate-spin-slow" style={{ animationDuration: '30s' }} />
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            className="fill-background"
          />
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;
