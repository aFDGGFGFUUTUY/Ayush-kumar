import React, { useState, useEffect } from 'react';
import { X, CheckCircle2, Clock, ChefHat, Bike, Home, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { CartItem } from '@/types/food';

interface OrderTrackingProps {
  isOpen: boolean;
  onClose: () => void;
  orderItems: CartItem[];
  totalPrice: number;
}

const orderSteps = [
  { id: 1, title: 'Order Placed', description: 'Your order has been confirmed', icon: Package },
  { id: 2, title: 'Preparing', description: 'Chef is cooking your food', icon: ChefHat },
  { id: 3, title: 'On the Way', description: 'Rider is delivering your order', icon: Bike },
  { id: 4, title: 'Delivered', description: 'Enjoy your meal!', icon: Home },
];

const OrderTracking: React.FC<OrderTrackingProps> = ({ isOpen, onClose, orderItems, totalPrice }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [riderPosition, setRiderPosition] = useState(0);

  // Simulate order progress
  useEffect(() => {
    if (!isOpen) {
      setCurrentStep(1);
      setRiderPosition(0);
      return;
    }

    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < 4) return prev + 1;
        clearInterval(stepInterval);
        return prev;
      });
    }, 5000);

    return () => clearInterval(stepInterval);
  }, [isOpen]);

  // Animate rider when on delivery step
  useEffect(() => {
    if (currentStep === 3) {
      const riderInterval = setInterval(() => {
        setRiderPosition((prev) => {
          if (prev >= 100) {
            clearInterval(riderInterval);
            return 100;
          }
          return prev + 2;
        });
      }, 100);

      return () => clearInterval(riderInterval);
    }
  }, [currentStep]);

  const estimatedTime = currentStep === 4 ? 'Delivered!' : `${(4 - currentStep) * 10 + 5} mins`;

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          "fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 transition-opacity duration-300",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      {/* Modal */}
      <div
        className={cn(
          "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95%] max-w-lg bg-background rounded-3xl shadow-xl z-50 transition-all duration-300",
          isOpen ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"
        )}
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground">Order Tracking</h2>
              <p className="text-sm text-muted-foreground">Order #FD{Date.now().toString().slice(-6)}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Estimated Time */}
          <div className="bg-gradient-primary rounded-2xl p-4 mb-6 text-primary-foreground text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Clock className="w-5 h-5" />
              <span className="text-sm font-medium">Estimated Time</span>
            </div>
            <p className="text-3xl font-bold">{estimatedTime}</p>
          </div>

          {/* Delivery Animation */}
          {currentStep === 3 && (
            <div className="mb-6 relative">
              <div className="bg-secondary rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-gradient-primary h-full transition-all duration-100 ease-linear"
                  style={{ width: `${riderPosition}%` }}
                />
              </div>
              <div 
                className="absolute -top-3 transition-all duration-100 ease-linear"
                style={{ left: `calc(${riderPosition}% - 16px)` }}
              >
                <div className="animate-bounce">
                  <span className="text-3xl">🏍️</span>
                </div>
              </div>
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>🍳 Kitchen</span>
                <span>🏠 Your Location</span>
              </div>
            </div>
          )}

          {/* Progress Steps */}
          <div className="space-y-4 mb-6">
            {orderSteps.map((step, index) => {
              const isCompleted = currentStep > step.id;
              const isCurrent = currentStep === step.id;
              const StepIcon = step.icon;

              return (
                <div key={step.id} className="flex items-start gap-4">
                  {/* Step Indicator */}
                  <div className="relative">
                    <div
                      className={cn(
                        "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500",
                        isCompleted ? "bg-food-gold text-foreground" : 
                        isCurrent ? "bg-gradient-primary text-primary-foreground animate-pulse-glow" : 
                        "bg-secondary text-muted-foreground"
                      )}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6" />
                      ) : (
                        <StepIcon className={cn("w-6 h-6", isCurrent && "animate-bounce")} />
                      )}
                    </div>
                    {/* Connector Line */}
                    {index < orderSteps.length - 1 && (
                      <div
                        className={cn(
                          "absolute left-1/2 top-12 w-0.5 h-6 -translate-x-1/2 transition-colors duration-500",
                          isCompleted ? "bg-food-gold" : "bg-secondary"
                        )}
                      />
                    )}
                  </div>

                  {/* Step Content */}
                  <div className={cn(
                    "flex-1 pb-6",
                    isCurrent && "animate-slide-up"
                  )}>
                    <h4 className={cn(
                      "font-semibold transition-colors duration-300",
                      isCompleted || isCurrent ? "text-foreground" : "text-muted-foreground"
                    )}>
                      {step.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                    {isCurrent && (
                      <div className="flex gap-1 mt-2">
                        <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Order Summary */}
          <div className="bg-card rounded-2xl p-4 mb-4">
            <h4 className="font-semibold text-foreground mb-3">Order Summary</h4>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {orderItems.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{item.quantity}x {item.name}</span>
                  <span className="font-medium">₹{item.price * item.quantity}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-border mt-3 pt-3 flex justify-between font-bold">
              <span>Total</span>
              <span className="text-gradient">₹{totalPrice}</span>
            </div>
          </div>

          {/* Close Button */}
          <Button 
            variant="hero" 
            size="lg" 
            className="w-full"
            onClick={onClose}
          >
            {currentStep === 4 ? 'Order Complete! 🎉' : 'Continue Shopping'}
          </Button>
        </div>
      </div>
    </>
  );
};

export default OrderTracking;
