import React from 'react';
import { Heart, Instagram, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-card border-t border-border py-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                <span className="text-xl">🍽️</span>
              </div>
              <div>
                <h3 className="font-display text-xl font-bold text-foreground">
                  Food Stall
                </h3>
                <p className="text-xs text-muted-foreground">by Ayush</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Delivering delicious food right to your doorstep. 
              Fresh, fast, and always flavorful.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {['Home', 'Menu', 'About Us', 'Contact'].map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Connect With Us</h4>
            <div className="flex gap-3">
              {[Instagram, Twitter, Facebook].map((Icon, index) => (
                <a
                  key={index}
                  href="#"
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-6 text-center space-y-2">
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-1">
            Made with <Heart className="w-4 h-4 text-food-red fill-food-red" /> by{' '}
            <span className="font-semibold text-foreground">Ayush Kumar</span>
          </p>
          <p className="text-sm text-muted-foreground italic">
            Heartfelt thanks to <span className="font-semibold text-foreground">Niwedita</span> for this amazing idea ❤️
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
