import React from 'react';
import { Star, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FoodItem } from '@/types/food';
import { useCart } from '@/context/CartContext';
import { cn } from '@/lib/utils';

interface FoodCardProps {
  item: FoodItem;
  index?: number;
}

const FoodCard: React.FC<FoodCardProps> = ({ item, index = 0 }) => {
  const { addToCart } = useCart();

  return (
    <div 
      className={cn(
        "group relative bg-card rounded-3xl overflow-hidden shadow-card hover:shadow-glow transition-all duration-500 animate-scale-in",
        "hover:-translate-y-2"
      )}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      {/* Image Container */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />

        {/* Rating Badge */}
        <div className="absolute top-3 right-3 flex items-center gap-1 bg-background/90 backdrop-blur-sm px-2 py-1 rounded-full">
          <Star className="w-3 h-3 fill-food-gold text-food-gold" />
          <span className="text-xs font-semibold">{item.rating}</span>
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors">
            {item.name}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
            {item.description}
          </p>
        </div>

        <div className="flex items-center justify-between pt-2">
          <div>
            <span className="text-2xl font-bold text-gradient">₹{item.price}</span>
          </div>
          
          <Button
            variant="cart"
            size="icon"
            onClick={() => addToCart(item)}
            className="group/btn"
          >
            <Plus className="w-5 h-5 transition-transform group-hover/btn:rotate-90" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FoodCard;
