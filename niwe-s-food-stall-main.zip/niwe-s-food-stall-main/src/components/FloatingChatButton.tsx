import React from 'react';
import { MessageCircle, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FloatingChatButtonProps {
  isOpen: boolean;
  onClick: () => void;
}

const FloatingChatButton: React.FC<FloatingChatButtonProps> = ({ isOpen, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-primary text-primary-foreground shadow-button hover:shadow-glow transition-all duration-300 z-40 flex items-center justify-center",
        "hover:scale-110 animate-pulse-glow",
        isOpen && "scale-0 opacity-0"
      )}
    >
      <MessageCircle className="w-6 h-6" />
      <span className="absolute -top-1 -right-1 w-4 h-4 bg-food-gold rounded-full flex items-center justify-center">
        <span className="text-[10px] font-bold text-food-brown">AI</span>
      </span>
    </button>
  );
};

export default FloatingChatButton;
