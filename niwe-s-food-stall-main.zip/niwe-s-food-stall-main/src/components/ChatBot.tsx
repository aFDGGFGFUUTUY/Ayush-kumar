import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { ChatMessage } from '@/types/food';
import { foodItems } from '@/data/foodData';

interface ChatBotProps {
  isOpen: boolean;
  onClose: () => void;
}

const generateBotResponse = (message: string): string => {
  const lowerMessage = message.toLowerCase();
  
  // Greeting responses
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return "Hey there! 👋 I'm Niwe, your food buddy at Food Stall by Ayush! How can I help you today? Would you like some recommendations or help finding something specific?";
  }
  
  // Menu/food queries
  if (lowerMessage.includes('menu') || lowerMessage.includes('what do you have') || lowerMessage.includes('food')) {
    return "We have an amazing selection! 🍽️ Our categories include:\n• 🍕 Pizza - Classic to specialty\n• 🍔 Burgers - Juicy and loaded\n• 🍛 Biryani - Aromatic and flavorful\n• 🥡 Chinese - Indo-Chinese favorites\n• 🍰 Desserts - Sweet endings\n\nWhat sounds good to you?";
  }
  
  // Popular items
  if (lowerMessage.includes('popular') || lowerMessage.includes('best') || lowerMessage.includes('recommend')) {
    const popularItems = foodItems.filter(item => item.isPopular);
    const names = popularItems.map(item => `${item.name} (₹${item.price})`).join('\n• ');
    return `Our most loved dishes are:\n• ${names}\n\nCustomers absolutely love these! Would you like to know more about any of them? 🌟`;
  }
  
  // Pizza queries
  if (lowerMessage.includes('pizza')) {
    const pizzas = foodItems.filter(item => item.category === 'pizza');
    const names = pizzas.map(item => `${item.name} - ₹${item.price}`).join('\n• ');
    return `🍕 Our Pizza Menu:\n• ${names}\n\nFreshly baked with love! Which one tempts you?`;
  }
  
  // Burger queries
  if (lowerMessage.includes('burger')) {
    const burgers = foodItems.filter(item => item.category === 'burger');
    const names = burgers.map(item => `${item.name} - ₹${item.price}`).join('\n• ');
    return `🍔 Our Burger Selection:\n• ${names}\n\nJuicy patties and fresh toppings! Want me to add one to your cart?`;
  }
  
  // Price queries
  if (lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('cheap')) {
    return "Our prices range from ₹99 to ₹449! 💰 We have budget-friendly options like Gulab Jamun (₹99) and premium dishes like BBQ Chicken Pizza (₹449). What's your budget?";
  }
  
  // Delivery queries
  if (lowerMessage.includes('delivery') || lowerMessage.includes('time')) {
    return "🚀 We deliver in just 30 minutes! And guess what? Delivery is absolutely FREE! Just place your order and sit back while we bring deliciousness to your door.";
  }
  
  // Thank you
  if (lowerMessage.includes('thank') || lowerMessage.includes('thanks')) {
    return "You're welcome! 😊 It's my pleasure to help. If you need anything else, just ask. Enjoy your food from Food Stall by Ayush! 🎉";
  }
  
  // Order help
  if (lowerMessage.includes('order') || lowerMessage.includes('cart')) {
    return "To order, simply browse our menu and tap the + button on any item you like! 🛒 Your cart will update automatically. When ready, head to checkout. Need help finding something specific?";
  }
  
  // About
  if (lowerMessage.includes('about') || lowerMessage.includes('who')) {
    return "Food Stall by Ayush is your go-to destination for delicious food! 🍽️ Created with love by Ayush Kumar, we bring you the best flavors from around the world. And I'm Niwe, your AI assistant here to make your ordering experience amazing! ✨";
  }
  
  // Default response
  return "I'd love to help you with that! 🤔 You can ask me about:\n• Our menu and categories\n• Popular dishes & recommendations\n• Prices and offers\n• Delivery information\n• How to order\n\nWhat would you like to know?";
};

const ChatBot: React.FC<ChatBotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hey! I'm Niwe 🤖 Your personal food assistant at Food Stall by Ayush! How can I make your day delicious today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate bot thinking
    setTimeout(() => {
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateBotResponse(inputValue),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          "fixed inset-0 bg-foreground/50 backdrop-blur-sm z-50 transition-opacity duration-300",
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={onClose}
      />

      {/* Chat Window */}
      <div
        className={cn(
          "fixed bottom-4 right-4 w-full max-w-sm h-[500px] bg-background rounded-3xl shadow-xl z-50 transition-all duration-300 ease-out overflow-hidden",
          isOpen ? "scale-100 opacity-100" : "scale-90 opacity-0 pointer-events-none"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 bg-gradient-primary text-primary-foreground">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold">Niwe</h3>
                <p className="text-xs opacity-80 flex items-center gap-1">
                  <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  Online
                </p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={cn(
                  "flex gap-2 animate-slide-up",
                  message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                )}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div
                  className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary'
                  )}
                >
                  {message.role === 'user' ? (
                    <User className="w-4 h-4" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-primary" />
                  )}
                </div>
                <div
                  className={cn(
                    "max-w-[80%] p-3 rounded-2xl whitespace-pre-line",
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground rounded-tr-none'
                      : 'bg-card shadow-soft rounded-tl-none'
                  )}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-2 animate-fade-in">
                <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-card shadow-soft p-3 rounded-2xl rounded-tl-none">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything..."
                className="flex-1 rounded-full bg-secondary/50 border-none focus:ring-2 focus:ring-primary/20"
              />
              <Button
                variant="cart"
                size="icon"
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isTyping}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatBot;
