import React from 'react';
import { Heart, Sparkles, Users, Award } from 'lucide-react';

const AboutUs: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
              <Heart className="w-4 h-4 fill-current" />
              Our Story
            </div>

            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
              About <span className="text-gradient">Food Stall</span>
            </h2>

            <p className="text-muted-foreground leading-relaxed">
              Welcome to Food Stall - your favorite destination for delicious food delivered right to your doorstep! 
              We believe that great food should be accessible to everyone, which is why we've created a platform that 
              brings the best flavors from top restaurants directly to you.
            </p>

            <div className="bg-card rounded-2xl p-6 shadow-soft border-l-4 border-primary">
              <h3 className="font-display text-xl font-bold text-foreground mb-2">
                Created by Ayush Kumar
              </h3>
              <p className="text-muted-foreground text-sm">
                This amazing food delivery platform was designed and developed by <strong className="text-foreground">Ayush Kumar</strong>, 
                with a passion for bringing delicious food closer to people.
              </p>
            </div>

            <div className="bg-food-gold/10 rounded-2xl p-6 shadow-soft border-l-4 border-food-gold">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-food-gold" />
                <h3 className="font-display text-xl font-bold text-foreground">
                  Special Thanks to Niwe
                </h3>
              </div>
              <p className="text-muted-foreground text-sm">
                A heartfelt thank you to <strong className="text-foreground">Niwe</strong> for this amazing idea 
                and inspiration that made Food Stall possible! Your vision helped create something truly special.
              </p>
            </div>
          </div>

          {/* Right Content - Stats */}
          <div className="grid grid-cols-2 gap-6">
            {[
              { icon: Users, label: 'Happy Customers', value: '10,000+', color: 'text-primary' },
              { icon: Award, label: 'Food Items', value: '500+', color: 'text-food-gold' },
              { icon: Heart, label: 'Cities Served', value: '50+', color: 'text-food-red' },
              { icon: Sparkles, label: '5-Star Reviews', value: '5,000+', color: 'text-food-coral' },
            ].map((stat, index) => (
              <div
                key={stat.label}
                className="bg-card rounded-3xl p-6 shadow-card text-center hover:shadow-glow transition-all duration-300 hover:-translate-y-2 animate-scale-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <stat.icon className={`w-10 h-10 mx-auto mb-3 ${stat.color}`} />
                <p className="font-display text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
