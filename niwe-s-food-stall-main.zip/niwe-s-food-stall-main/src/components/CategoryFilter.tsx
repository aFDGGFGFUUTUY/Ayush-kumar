import React from 'react';
import { cn } from '@/lib/utils';
import { Category } from '@/types/food';

interface CategoryFilterProps {
  categories: Category[];
  activeCategory: string;
  onCategoryChange: (categoryId: string) => void;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({
  categories,
  activeCategory,
  onCategoryChange,
}) => {
  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground">
            Categories
          </h2>
          <span className="text-sm text-muted-foreground">
            {categories.find(c => c.id === activeCategory)?.count || 0} items
          </span>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
          {categories.map((category, index) => (
            <button
              key={category.id}
              onClick={() => onCategoryChange(category.id)}
              className={cn(
                "flex flex-col items-center min-w-[80px] p-4 rounded-2xl transition-all duration-300 animate-slide-up",
                activeCategory === category.id
                  ? "bg-gradient-primary text-primary-foreground shadow-button scale-105"
                  : "bg-card hover:bg-secondary shadow-card hover:scale-105"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-2xl mb-2">{category.icon}</span>
              <span className="text-sm font-medium whitespace-nowrap">
                {category.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryFilter;
